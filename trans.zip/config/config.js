module.exports = {
	HOST: "localhost",
	USER: "hitechpl_transport",
	PASSWORD: "Oriis_transport",
	DB: "hitechpl_transport_biller",
	PORT:3000,
	dialect: "mysql",
	pool: {
	  max: 5,
	  min: 0,
	  acquire: 30000,
	  idle: 10000
	}
  };
  